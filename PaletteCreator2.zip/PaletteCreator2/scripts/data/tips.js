class Tips{
    static tips = [
        'Choose a category',
        'Choose a pre-made color',
        'Pick your own color',
        'Main palette\'s color preview',
        'How far apart are the colors',
        'Go towards colder or hotter tones',
        'Include other colors in the palette',
        'Export your palette'
    ];
}