window.onload = function(){
    HTInitialize();
    FaInitialize();
    PpInitialize();
    FindPreviews();
}